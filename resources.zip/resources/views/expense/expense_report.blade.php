@extends('tmp')

@section('title', $pagetitle)
 

@section('content')

<div class="main-content">

 <div class="page-content">
 <div class="container-fluid">
 <div class="row">
  <div class="col-12">
  
 @if (session('error'))

 <div class="alert alert-{{ Session::get('class') }} p-1" id="success-alert">
                    
                   {{ Session::get('error') }}  
                </div>

@endif

 @if (count($errors) > 0)
                                 
                            <div >
                <div class="alert alert-danger p-1   border-3">
                   <p class="font-weight-bold"> There were some problems with your input.</p>
                    <ul>
                        
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>

                        @endforeach
                    </ul>
                </div>
                </div>
 
            @endif

            
  <div class="card">
      <div class="card-body">
          <!-- enctype="multipart/form-data" -->
          <form action="{{URL('/ExpenseReport1')}}" method="post" name="form1" id="form1"> {{csrf_field()}} 

 
            
                
 
            


            
 @include('components.start_end_date')
              
              
         
      </div>
      <div class="card-footer bg-light">
        <button type="submit" class="btn btn-success w-lg float-right" id="online">Submit</button>
                    <a href="{{URL('/')}}" class="btn btn-secondary w-lg float-right">Cancel</a>
      </div>
  </div>
   </form> 
  </div>
</div>

        </div>
      </div>
    </div>
    <!-- END: Content-->
   <!-- END: Content-->
 <script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>


<script>
  $('#pdf').click(function(){
     
   $('#form1').attr('action', '{{URL("/VoucherReport1PDF")}}');
   $('#form1').attr('target', '_blank');
   $('#form1').submit();

});


  $('#online').click(function(){
     
   $('#form1').attr('action', '{{URL("/ExpenseReport1")}}');
    

});


</script>
  @endsection